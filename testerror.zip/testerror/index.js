const express = require('express')
const app = express()


app.get('/', (req, res) => {
    res.send("Hello lungtu")
})

app.get('/home2', function (req, res){
    res.sendFile(__dirname + '/home2.html')
})

app.get('*', function(req, res){
    res.sendFile(__dirname + '/error404.html')
})

app.listen(3000, () => {
    console.log("Start Server at Port [3000]")
})
